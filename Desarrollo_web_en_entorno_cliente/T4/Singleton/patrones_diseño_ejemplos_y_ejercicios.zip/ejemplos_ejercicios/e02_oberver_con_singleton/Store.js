
export class ThemeStore {
  constructor() {
    //implementar
  }

  subscribe() {
    //implementar
  }

  notify() {
    // implementar 
  }

  toggleTheme() {
    this.state.theme = this.state.theme === 'light' ? 'dark' : 'light';
    this.notify();
  }

}


export class StoreSub {
  // recibe un nodo del DOM
  constructor() {
    //implementar
  }
  // recibe el estado state, que contiene { theme: 'light' } o {theme: 'dark'}
  update(state) {
    //implementar
  }
}
