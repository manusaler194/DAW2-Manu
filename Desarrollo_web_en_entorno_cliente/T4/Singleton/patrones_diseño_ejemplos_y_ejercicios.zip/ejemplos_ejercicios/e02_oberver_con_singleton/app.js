import { ThemeStore , StoreSub } from './Store.js';

// Aquí inicializamos directamente el singleton
const store = new ThemeStore();

// Creamos los subscribers para cada elemento

// Suscribimos al store

// Evento del botón

// Inicializamos la vista la primera vez con el tema por defecto
store.notify();
