

if (navegadoe =="Edge") {
    console.log("Edge")

} else if (navigator =="Chrome") {
    console.log("Chrome")
}else if (navigator =="Firefox") {
    console.log("Firefox")
}else if (navigator =="Safari") {
    console.log("Safari")
}else if (navigator =="Opera") {
    console.log("Opera")
}else if (navigator =="no lo se") {
    console.log("no lo se")
}

