let fecha1 = new Date('2005-12-20');
let fecha2 = new Date(2005,11,20);